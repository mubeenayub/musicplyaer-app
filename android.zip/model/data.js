const songs =[
    {
        title:"Kontho",
        artist:"Anupam Roy",
        image:require("../assets/artwork/kontho.jpeg"),
        id:"1",
    },
    {
        title:"Humarah",
        artist:"sachet Tandon",
        image:require("../assets/artwork/Hamrah.jpeg"),
        id:"2",
    },
    {
        title:"Kyon",
        artist:"B Praak, Payal Dev",
        image:require("../assets/artwork/kyon.jpeg"),
        id:"3",
    },
    {
        title:"Buzz",
        artist:"Aastha Gill,Badshah",
        image:require("../assets/artwork/buzz.jpeg"),
        id:"4",
    },
    {
        title:"Sunflower",
        artist:"Post Melone, Swae Lee",
        image:require("../assets/artwork/sunflower.png"),
        id:"5",
    }
];

 export default songs;